package com.maven.OnlineShoppingSB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineShoppingSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
