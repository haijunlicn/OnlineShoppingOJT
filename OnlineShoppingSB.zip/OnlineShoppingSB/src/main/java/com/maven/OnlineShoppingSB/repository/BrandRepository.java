package com.maven.OnlineShoppingSB.repository;

import com.maven.OnlineShoppingSB.entity.BrandEntity;
import com.maven.OnlineShoppingSB.entity.CategoryEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BrandRepository extends JpaRepository<BrandEntity, Long> {
	//List<CategoryEntity> findByDelFgFalse();
	List<BrandEntity> findByDelFg(int delFg);
}
