export interface SelectItemDTO {
  label: string;
  value: string | boolean;
}
