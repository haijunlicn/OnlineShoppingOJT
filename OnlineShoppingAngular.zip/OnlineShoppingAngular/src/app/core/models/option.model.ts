
export interface OptionDTO {
  type: string;
  values: string[];
}

export interface OptionTypeDTO {
  id: string;
  name: string;
  values: string[];
}