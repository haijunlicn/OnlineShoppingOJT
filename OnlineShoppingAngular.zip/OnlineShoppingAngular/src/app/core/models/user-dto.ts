export interface UserDTO {
}
